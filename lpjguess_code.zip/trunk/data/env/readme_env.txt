Environmental data for demonstration versions of LPJ-GUESS
==========================================================

The following files are available in directory:
  (users with id) /user/home/ftp/pub/ben/guess030124/data/env

  Cramer & Leemans (unpublished) interpolated modern climate data
  (global, 0.5x0.5 degree grid)

    tmp30_21.grd    (mean monthly temperature)
    prc30_21.grd    (monthly rainfall)
    clo30_21.grd    (mean monthly sunshine %)
 
  LPJ soil codes (c.f. Sitch et al 2001) (global, 0.5x0.5 degree grid)

    soils-lpj.grd

NOTE: these files are provided in conjunction with the demonstration
      input/output module of LPJ-GUESS, and are ONLY for use in EVALUATING
      LPJ-GUESS. They must NOT be used for any other purpose without the
      explicit permission of the owners of the data. Enquiries to Ben
      Smith.


Ben Smith, 11 June 2003
benjamin.smith@nateko.lu.se

