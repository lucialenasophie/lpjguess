NPROCESS=6
if [[ $ARCH == "aurora" ]]; then
    NPROCESS=20
fi
