NPROCESS=30
if [[ $ARCH == "aurora" ]]; then
    NPROCESS=100
fi
